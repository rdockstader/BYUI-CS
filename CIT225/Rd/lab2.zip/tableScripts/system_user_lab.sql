-- ------------------------------------------------------------------
-- Create system_user_lab table and sequence and seed data.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE system_user_lab
( system_user_lab_id            NUMBER
, system_user_name          VARCHAR2(20) CONSTRAINT nn_system_user_lab_1 NOT NULL
, system_user_group_id      NUMBER       CONSTRAINT nn_system_user_lab_2 NOT NULL
, system_user_type          NUMBER       CONSTRAINT nn_system_user_lab_3 NOT NULL
, first_name                  	VARCHAR2(20)
, middle_name                 	VARCHAR2(20)
, last_name                   	VARCHAR2(20)
, created_by                  	NUMBER       CONSTRAINT nn_system_user_lab_4 NOT NULL
, creation_date               	DATE         CONSTRAINT nn_system_user_lab_5 NOT NULL
, last_updated_by             	NUMBER       CONSTRAINT nn_system_user_lab_6 NOT NULL
, last_update_date            	DATE         CONSTRAINT nn_system_user_lab_7 NOT NULL
, CONSTRAINT pk_system_user_lab_1 PRIMARY KEY(system_user_lab_id));

-- Create sequence.
CREATE SEQUENCE system_user_lab_s1 START WITH 1001;

-- Seed initial record in the system_user_lab table.
INSERT INTO system_user_lab
( system_user_lab_id
, system_user_name
, system_user_group_id
, system_user_type
, created_by
, creation_date
, last_updated_by
, last_update_date)
VALUES
( 1,'SYSADMIN', 1, 1, 1, SYSDATE, 1, SYSDATE);

-- ------------------------------------------------------------------
-- Alter system_user_lab table to include self-referencing foreign key constraints.
-- ------------------------------------------------------------------
ALTER TABLE system_user_lab
ADD CONSTRAINT fk_system_user_lab_1 FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id);

ALTER TABLE system_user_lab
ADD CONSTRAINT fk_system_user_lab_2 FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id);
