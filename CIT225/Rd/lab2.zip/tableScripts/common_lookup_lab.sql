-- ------------------------------------------------------------------
-- Create common_lookup_lab table and sequence and seed data.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE common_lookup_lab
( common_lookup_lab_id            	NUMBER
, common_lookup_context       		VARCHAR2(30) CONSTRAINT nn_clookup_lab_1 NOT NULL
, common_lookup_type          		VARCHAR2(30) CONSTRAINT nn_clookup_lab_2 NOT NULL
, common_lookup_meaning       		VARCHAR2(30) CONSTRAINT nn_clookup_lab_3 NOT NULL
, created_by                  		NUMBER       CONSTRAINT nn_clookup_lab_4 NOT NULL
, creation_date               		DATE         CONSTRAINT nn_clookup_lab_5 NOT NULL
, last_updated_by             		NUMBER       CONSTRAINT nn_clookup_lab_6 NOT NULL
, last_update_date            		DATE         CONSTRAINT nn_clookup_lab_7 NOT NULL
, CONSTRAINT pk_c_lookup_lab_1    		PRIMARY KEY(common_lookup_lab_id)
, CONSTRAINT fk_c_lookup_lab_1    		FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id)
, CONSTRAINT fk_c_lookup_lab_2    		FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id));

-- Create a non-unique index.
CREATE INDEX common_lookup_lab_n1
  ON common_lookup_lab(common_lookup_context);

-- Create a unique index.
CREATE UNIQUE INDEX common_lookup_lab_u2
  ON common_lookup_lab(common_lookup_context,common_lookup_type);

-- Create a sequence.
CREATE SEQUENCE common_lookup_lab_s1 START WITH 1001;

-- Seed the common_lookup_lab table with 18 records.
INSERT INTO common_lookup_lab VALUES
( 1,'system_user_lab','SYSTEM_ADMIN','System Administrator', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( 2,'system_user_lab','DBA','Database Administrator', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'contact_lab','EMPLOYEE','Employee', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'contact_lab','CUSTOMER','Customer', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'member_lab','INDIVIDUAL','Individual member_labship', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'member_lab','GROUP','Group member_labship', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'member_lab','DISCOVER_CARD','Discover Card', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'member_lab','MASTER_CARD','Master Card', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'member_lab','VISA_CARD','VISA Card', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'MULTIPLE','HOME','Home', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'MULTIPLE','WORK','Work', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'item_lab','DVD_FULL_SCREEN','DVD: Full Screen', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'item_lab','DVD_WIDE_SCREEN','DVD: Wide Screen', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'item_lab','NINTENDO_GAMECUBE','Nintendo GameCube', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'item_lab','PLAYSTATION2','PlayStation2', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'item_lab','XBOX','XBOX', 1, SYSDATE, 1, SYSDATE);

INSERT INTO common_lookup_lab VALUES
( common_lookup_lab_s1.nextval,'item_lab','BLU-RAY','Blu-ray', 1, SYSDATE, 1, SYSDATE);

-- Add constraints to the system_user_lab table dependent on the common_lookup_lab table.
ALTER TABLE system_user_lab
ADD CONSTRAINT fk_system_user_lab_3 FOREIGN KEY(system_user_group_id)
    REFERENCES common_lookup_lab(common_lookup_lab_id);

ALTER TABLE system_user_lab
ADD CONSTRAINT fk_system_user_lab_4 FOREIGN KEY(system_user_type)
    REFERENCES common_lookup_lab(common_lookup_lab_id);
