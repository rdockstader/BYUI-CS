-- ------------------------------------------------------------------
-- Create rental_lab_item_lab table and sequence.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE rental_item_lab
( rental_item_lab_id              NUMBER
, rental_lab_id                   NUMBER CONSTRAINT nn_rental_lab_item_lab_1 NOT NULL
, item_lab_id                     NUMBER CONSTRAINT nn_rental_lab_item_lab_2 NOT NULL
, created_by                  NUMBER CONSTRAINT nn_rental_lab_item_lab_3 NOT NULL
, creation_date               DATE   CONSTRAINT nn_rental_lab_item_lab_4 NOT NULL
, last_updated_by             NUMBER CONSTRAINT nn_rental_lab_item_lab_5 NOT NULL
, last_update_date            DATE   CONSTRAINT nn_rental_lab_item_lab_6 NOT NULL
, CONSTRAINT pk_rental_lab_item_lab_1 PRIMARY KEY(rental_item_lab_id)
, CONSTRAINT fk_rental_lab_item_lab_1 FOREIGN KEY(rental_lab_id) REFERENCES rental_lab(rental_lab_id)
, CONSTRAINT fk_rental_lab_item_lab_2 FOREIGN KEY(item_lab_id) REFERENCES item_lab(item_lab_id)
, CONSTRAINT fk_rental_lab_item_lab_3 FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id)
, CONSTRAINT fk_rental_lab_item_lab_4 FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id));

-- Create a sequence.
CREATE SEQUENCE rental_item_lab_s1 START WITH 1001;
