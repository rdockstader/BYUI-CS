-- ------------------------------------------------------------------
-- Create contact_lab table and sequence and seed data.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE contact_lab
( contact_lab_id              	NUMBER
, member_lab_id               	NUMBER       CONSTRAINT nn_contact_lab_1 NOT NULL
, contact_type                	NUMBER       CONSTRAINT nn_contact_lab_2 NOT NULL
, first_name                  	VARCHAR2(20) CONSTRAINT nn_contact_lab_3 NOT NULL
, middle_name                 	VARCHAR2(20)
, last_name                   	VARCHAR2(20) CONSTRAINT nn_contact_lab_4 NOT NULL
, created_by                  	NUMBER       CONSTRAINT nn_contact_lab_5 NOT NULL
, creation_date               	DATE         CONSTRAINT nn_contact_lab_6 NOT NULL
, last_updated_by             	NUMBER       CONSTRAINT nn_contact_lab_7 NOT NULL
, last_update_date            	DATE         CONSTRAINT nn_contact_lab_8 NOT NULL
, CONSTRAINT pk_contact_lab_1   PRIMARY KEY(contact_lab_id)
, CONSTRAINT fk_contact_lab_1   FOREIGN KEY(member_lab_id) REFERENCES member_lab(member_lab_id)
, CONSTRAINT fk_contact_lab_2   FOREIGN KEY(contact_type) REFERENCES common_lookup_lab(common_lookup_lab_id)
, CONSTRAINT fk_contact_lab_3   FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id)
, CONSTRAINT fk_contact_lab_4   FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id));

-- Create non-unique index.
CREATE INDEX contact_lab_n1 ON contact_lab(member_lab_id);
CREATE INDEX contact_lab_n2 ON contact_lab(contact_type);

-- Create sequence.
CREATE SEQUENCE contact_lab_s1 START WITH 1001;