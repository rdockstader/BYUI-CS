-- ------------------------------------------------------------------
-- Create STREET_address_lab table and sequence.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE street_address_lab
( street_address_lab_id           	NUMBER
, address_lab_id                  	NUMBER       CONSTRAINT nn_saddress_lab_1 NOT NULL
, street_address              		VARCHAR2(30) CONSTRAINT nn_saddress_lab_2 NOT NULL
, created_by                  		NUMBER       CONSTRAINT nn_saddress_lab_3 NOT NULL
, creation_date               		DATE         CONSTRAINT nn_saddress_lab_4 NOT NULL
, last_updated_by             		NUMBER       CONSTRAINT nn_saddress_lab_5 NOT NULL
, last_update_date            		DATE         CONSTRAINT nn_saddress_lab_6 NOT NULL
, CONSTRAINT pk_s_address_lab_1   	PRIMARY KEY(street_address_lab_id)
, CONSTRAINT fk_s_address_lab_1   	FOREIGN KEY(address_lab_id) REFERENCES address_lab(address_lab_id)
, CONSTRAINT fk_s_address_lab_3   	FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id)
, CONSTRAINT fk_s_address_lab_4   	FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id));

-- Create sequence.
CREATE SEQUENCE street_address_lab_s1 START WITH 1001;
