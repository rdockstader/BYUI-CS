-- ------------------------------------------------------------------
-- Create address_lab table and sequence.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE address_lab
( address_lab_id              	NUMBER
, contact_lab_id              	NUMBER       CONSTRAINT nn_address_lab_1 NOT NULL
, address_type                	NUMBER       CONSTRAINT nn_address_lab_2 NOT NULL
, city                        	VARCHAR2(30) CONSTRAINT nn_address_lab_3 NOT NULL
, state_province              	VARCHAR2(30) CONSTRAINT nn_address_lab_4 NOT NULL
, postal_code                 	VARCHAR2(20) CONSTRAINT nn_address_lab_5 NOT NULL
, created_by                  	NUMBER       CONSTRAINT nn_address_lab_6 NOT NULL
, creation_date               	DATE         CONSTRAINT nn_address_lab_7 NOT NULL
, last_updated_by             	NUMBER       CONSTRAINT nn_address_lab_8 NOT NULL
, last_update_date            	DATE         CONSTRAINT nn_address_lab_9 NOT NULL
, CONSTRAINT pk_address_lab_1   PRIMARY KEY(address_lab_id)
, CONSTRAINT fk_address_lab_1   FOREIGN KEY(contact_lab_id) REFERENCES contact_lab(contact_lab_id)
, CONSTRAINT fk_address_lab_2   FOREIGN KEY(address_type) REFERENCES common_lookup_lab(common_lookup_lab_id)
, CONSTRAINT fk_address_lab_3   FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id)
, CONSTRAINT fk_address_lab_4   FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id));

-- Create a non-unique index.
CREATE INDEX address_lab_n1 ON address_lab(contact_lab_id);
CREATE INDEX address_lab_n2 ON address_lab(address_type);

-- Create a sequence.
CREATE SEQUENCE address_lab_s1 START WITH 1001;