- ------------------------------------------------------------------
-- Create member_lab table and sequence and seed data.
-- ------------------------------------------------------------------

-- Create table.
CREATE TABLE member_lab
( member_lab_id                 NUMBER
, member_lab_type               NUMBER
, account_number              	VARCHAR2(10) CONSTRAINT nn_member_lab_2 NOT NULL
, credit_card_number          	VARCHAR2(20) CONSTRAINT nn_member_lab_3 NOT NULL
, credit_card_type            	NUMBER       CONSTRAINT nn_member_lab_4 NOT NULL
, created_by                  	NUMBER       CONSTRAINT nn_member_lab_5 NOT NULL
, creation_date               	DATE         CONSTRAINT nn_member_lab_6 NOT NULL
, last_updated_by             	NUMBER       CONSTRAINT nn_member_lab_7 NOT NULL
, last_update_date            	DATE         CONSTRAINT nn_member_lab_8 NOT NULL
, CONSTRAINT pk_member_lab_1    PRIMARY KEY(member_lab_id)
, CONSTRAINT fk_member_lab_1    FOREIGN KEY(member_lab_type) REFERENCES common_lookup_lab(common_lookup_lab_id)
, CONSTRAINT fk_member_lab_2    FOREIGN KEY(credit_card_type) REFERENCES common_lookup_lab(common_lookup_lab_id)
, CONSTRAINT fk_member_lab_3    FOREIGN KEY(created_by) REFERENCES system_user_lab(system_user_lab_id)
, CONSTRAINT fk_member_lab_4    FOREIGN KEY(last_updated_by) REFERENCES system_user_lab(system_user_lab_id));

-- Create a non-unique index.
CREATE INDEX member_lab_n1 ON member_lab(credit_card_type);

-- Create a sequence.
CREATE SEQUENCE member_lab_s1 START WITH 1001;