package prove02;

public interface Teleporter {
    public void teleport(int rows, int cols);
}
