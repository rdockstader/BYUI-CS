package prove02;

public enum Direction {
    above, below, left, right
}
