package com.rdockstader;


public class HelloWorld {

    public void sayHello() {
        System.out.println("Hello, world!");
    }

    public static void main(String[] args) {
	    HelloWorld helloWorld = new HelloWorld();

	    helloWorld.sayHello();
    }


}
